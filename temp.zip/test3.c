#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(void)
{
  create_container();
  create_container();
  create_container();

  int fd0 = open("myfile.txt", O_CREATE);
  close(fd0);
  printf(1, "Check 11 Done\n");

  int fd00 = open("myfile.txt", O_WRONLY);
  char* d = "Sarthak";
  write(fd00, d, 7);
  close(fd00);
  printf(1, "Check 12 Done\n");

  int fd3 = open("myfile.txt", O_RDONLY);
  char dd[8];
  read(fd3, dd, 7);
  close(fd3);
  printf(1, "In main file : %s\n", dd);
  printf(1, "Check 13 Done\n");

  int cid = fork();
  if(cid == 0){
    join_container(1);
    // printf(1, "Check between the lines\n");
    int fd1 = open("myfile.txt",O_CREATE);
    // printf(1, "Check between the lines\n");
    close(fd1);
    printf(1, "Check 1 done\n");

    int fd11 = open("myfile.txt", O_WRONLY);
    char* v = "Vishnoi";
    printf(1, "Ye Chala?\n");
    int writee = write(fd11, v, 7);
    printf(1,"1: %d BRO\n",writee);
    close(fd11);
    printf(1, "Check 2 done\n");

    char buf[50];
    int fd2 = open("myfile.txt", O_RDONLY);
    int howMuch = read(fd2, buf, sizeof(buf));
    printf(1, "Printing Buf\n");
    printf(1, "%s\n", buf);
    printf(1, "How much it read %d\n", howMuch);
    close(fd2);
    printf(1, "Check 3 done\n");
    exit();
  }
  wait();
  exit();
}
